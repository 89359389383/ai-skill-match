<!-- Footer -->
<footer class="bg-gradient-to-br from-[#FC4C0C] via-orange-500 to-amber-500 text-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            <!-- Brand Section -->
            <div class="space-y-4">
                <div class="flex items-center gap-2">
                    <div class="p-2 bg-white/10 rounded-lg backdrop-blur-sm">
                        <svg class="w-6 h-6 text-indigo-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/>
                        </svg>
                    </div>
                    <span class="text-xl font-bold text-white">
                        AIスキルマッチ
                    </span>
                </div>
                <p class="text-gray-300 text-sm leading-relaxed">
                    AIスキルを持つ人材と企業を結びつけるプラットフォーム。
                    知識を共有し、スキルを販売し、未来を創造する。
                </p>
                <div class="flex gap-3">
                    <a href="https://twitter.com" target="_blank" class="p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-all">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                        </svg>
                    </a>
                    <a href="https://github.com" target="_blank" class="p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-all">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                        </svg>
                    </a>
                    <a href="mailto:info@example.com" class="p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-all">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                        </svg>
                    </a>
                </div>
            </div>

            <!-- Service -->
            <div class="space-y-4">
                <h3 class="font-semibold text-lg text-white">サービス</h3>
                <ul class="space-y-2">
                    <li>
                        <a href="https://aitech-japan.co.jp/#service" target="_blank" class="text-gray-300 hover:text-white text-sm transition-colors">
                            サービス
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Support -->
            <div class="space-y-4">
                <h3 class="font-semibold text-lg text-white">サポート</h3>
                <ul class="space-y-2">
                    <li><a href="https://aitech-japan.co.jp/contact" target="_blank" class="text-gray-300 hover:text-white text-sm">お問い合わせ</a></li>
                    <li><a href="#" class="text-gray-300 hover:text-white text-sm">利用規約</a></li>
                    <li><a href="https://aitech-japan.co.jp/3" target="_blank" class="text-gray-300 hover:text-white text-sm">プライバシーポリシー</a></li>
                </ul>
            </div>

            <!-- Company -->
            <div class="space-y-4">
                <h3 class="font-semibold text-lg text-white">企業情報</h3>
                <ul class="space-y-2">
                    <li><a href="https://aitech-japan.co.jp/company" target="_blank" class="text-gray-300 hover:text-white text-sm">運営会社</a></li>
                    <li><a href="https://aitech-japan.co.jp/careers" target="_blank" class="text-gray-300 hover:text-white text-sm">採用情報</a></li>
                    <li><a href="https://aitech-japan.co.jp/#news" target="_blank" class="text-gray-300 hover:text-white text-sm">プレスリリース</a></li>
                </ul>
            </div>
        </div>

        <!-- Bottom -->
        <div class="pt-8 border-t border-white/10">
            <div class="flex flex-col md:flex-row justify-between items-center gap-4">
                <p class="text-gray-300 text-sm">
                    © <span id="publicCurrentYear"></span> AIスキルマッチ. All rights reserved.
                </p>
            </div>
        </div>
    </div>
</footer>

<script>
    (function () {
        const el = document.getElementById('publicCurrentYear');
        if (el) el.textContent = new Date().getFullYear();
    })();
</script>