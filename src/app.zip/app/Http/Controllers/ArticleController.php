<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreArticleRequest;
use App\Models\Article;
use App\Services\ArticleService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;

class ArticleController extends Controller
{
    /**
     * 記事一覧（ログイン不要）。
     *
     * やること:
     * - 公開記事を新着順で取得
     * - 将来: 検索/ソート/ページングを仕様に合わせて追加
     */
    public function index(Request $request)
    {
        $articles = Article::query()
            ->with(['user', 'tags', 'user.freelancer', 'user.company'])
            ->where('status', 1)
            ->when($request->filled('user'), function ($q) use ($request) {
                $q->where('user_id', (int) $request->query('user'));
            })
            ->orderByDesc('published_at')
            ->paginate(30)
            ->withQueryString();

        if (view()->exists('articles.index')) {
            return view('articles.index', compact('articles'));
        }

        return view('welcome');
    }

    /**
     * 記事詳細（ログイン不要）。
     */
    public function show(Request $request, Article $article)
    {
        $article->load(['user', 'tags', 'user.freelancer', 'user.company']);

        // 閲覧数カウント（詳細ページ表示時のみ +1）
        // - ログイン中: user_id 判定
        // - 未ログイン: guest_token（cookie）判定
        // - 同一人物は24時間以内の再閲覧では +1 しない
        // - 作成者の閲覧（本人）はカウントしない
        $viewerId = null;
        if (Auth::guard('freelancer')->check()) {
            $viewerId = (int) Auth::guard('freelancer')->user()->id;
        } elseif (Auth::guard('company')->check()) {
            $viewerId = (int) Auth::guard('company')->user()->id;
        }

        $guestToken = null;
        $needsGuestCookie = false;
        if ($viewerId === null) {
            $guestToken = $request->cookie('guest_token');
            if (empty($guestToken)) {
                $guestToken = (string) Str::uuid();
                $needsGuestCookie = true;
            }
        }

        $shouldIncrement = true;
        if ($viewerId !== null && $viewerId === (int) $article->user_id) {
            $shouldIncrement = false;
        }

        $cacheKey = $viewerId !== null
            ? "article_viewed:{$article->id}:u:{$viewerId}"
            : "article_viewed:{$article->id}:g:{$guestToken}";

        $didIncrement = false;
        if ($shouldIncrement) {
            if (Cache::add($cacheKey, 1, 60 * 60 * 24)) {
                $article->increment('views_count');
                $article->views_count = (int) ($article->views_count ?? 0) + 1;
                $didIncrement = true;
            }
        }

        if (view()->exists('articles.show')) {
            $response = response()->view('articles.show', compact('article'));
            if ($needsGuestCookie) {
                $response->withCookie(cookie('guest_token', $guestToken, 60 * 24 * 365));
            }
            return $response;
        }

        $response = response()->view('welcome');
        if ($needsGuestCookie) {
            $response->withCookie(cookie('guest_token', $guestToken, 60 * 24 * 365));
        }
        return $response;
    }

    /**
     * 記事投稿画面（ログイン必須）。
     *
     * 注意:
     * - 認証は routes 側で auth.any を付ける
     * - ここでは「フォーム表示」に徹する（保存は store）
     */
    public function create()
    {
        if (view()->exists('articles.create')) {
            return view('articles.create');
        }

        return view('welcome');
    }

    /**
     * 記事投稿（ログイン必須）。
     *
     * やること:
     * - 入力を validate
     * - Service に渡して保存（タグも含む）
     * - 完了後、一覧へ戻す（仕様が固まったら詳細へ）
     */
    public function store(StoreArticleRequest $request, ArticleService $service)
    {
        // auth.any ミドルウェアで request()->user() が取れる前提
        $user = $request->user();
        if (!$user) {
            return redirect()->route('auth.login.form');
        }

        // 仕様（記事投稿画面）に沿った入力チェックは FormRequest 側へ移動。
        // Controller では “validated 済みの安全な配列” だけを受け取る。
        $validated = $request->validated();

        // アイキャッチ画像がアップロードされていれば保存して URL を validated にセットする
        if ($request->hasFile('eyecatch_image')) {
            try {
                $file = $request->file('eyecatch_image');
                $path = $file->store('eyecatches', 'public');
                $validated['eyecatch_image_url'] = \Illuminate\Support\Facades\Storage::disk('public')->url($path);
            } catch (\Throwable $e) {
                // 保存に失敗しても投稿処理自体は継続（バリデーションで弾きたい場合は別途対応）
                \Illuminate\Support\Facades\Log::warning('[ArticleController@store] eyecatch upload failed: ' . $e->getMessage());
            }
        }

        $article = $service->store($user, $validated);

        return redirect()->route('articles.index')->with('status', '記事を投稿しました。');
    }
}

