<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateArticleRequest extends FormRequest
{
    public function authorize(): bool
    {
        // “本人のみ” の権限チェックは Controller（ensureOwner）で行う。
        // FormRequest は入力のバリデーションに集中する。
        return true;
    }

    public function rules(): array
    {
        return [
            'title' => ['required', 'string', 'max:255'],
            'excerpt' => ['required', 'string', 'max:200'],
            'category' => ['required', 'string', 'max:50'],
            'eyecatch_image_url' => ['nullable', 'url'],
            'eyecatch_image' => ['nullable', 'file', 'image', 'max:5120'],
            'body_html' => [
                'required',
                'string',
                'max:50000',
                function ($attribute, $value, $fail) {
                    if (trim(strip_tags($value)) === '') {
                        $fail('本文を入力してください。');
                    }
                },
            ],
            'structure' => ['nullable', 'array'],
            'tags' => ['required', 'array', 'min:4', 'max:16'],
            'tags.*' => ['string', 'max:50'],

            // 公開設定（任意）
            'is_published' => ['nullable', 'in:0,1'],
        ];
    }

    public function messages(): array
    {
        return [
            'title.required' => 'タイトルは必須です。',
            'excerpt.required' => '概要は必須です。',
            'excerpt.max' => '概要は200文字以内で入力してください。',
            'category.required' => 'カテゴリーは必須です。',
            'eyecatch_image_url.url' => 'アイキャッチ画像URLは正しいURL形式で入力してください。',
            'eyecatch_image.image' => 'アイキャッチ画像は画像ファイルを選択してください。',
            'eyecatch_image.max' => 'アイキャッチ画像は5MB以内にしてください。',
            'body_html.required' => '本文を入力してください。',
            'body_html.max' => '本文が長すぎます。',
            'tags.min' => 'タグは最低4個入力してください。',
            'tags.max' => 'タグは最大16個までです。',
            'is_published.in' => '公開設定の値が不正です。',
        ];
    }
}

